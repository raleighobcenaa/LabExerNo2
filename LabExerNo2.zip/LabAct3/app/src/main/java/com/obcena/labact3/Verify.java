package com.obcena.labact3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class Verify extends AppCompatActivity {

    EditText etSchool, etUS, etUS1, etUS2, etUS3, etUS4, etUS5, etUS6, etUS7; //declaring variables
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);
        etSchool = findViewById(R.id.etSchool); //assigning value to the variable
    }

    public void validate(View view){
        sp = getSharedPreferences("data1", MODE_PRIVATE); // mode private is a non static constant
        String us = sp.getString("school", null);
        String us1 = sp.getString("school1", null);
        String us2 = sp.getString("school2", null);
        String us3 = sp.getString("school3", null);
        String us4 = sp.getString("school4", null);
        String us5 = sp.getString("school5", null);
        String us6 = sp.getString("school6", null);
        String us7 = sp.getString("school7", null);

        String school = etSchool.getText().toString();
        if (school.equals(us) || school.equals(us1) || school.equals(us2) || school.equals(us3) ||
                school.equals(us4) || school.equals(us5) || school.equals(us6)|| school.equals(us7)){
            Toast.makeText(this, "School exists in the UAAP Schools.", Toast.LENGTH_LONG);
        } else {
            Toast.makeText(this, "School does not exist in the UAAP Schools .", Toast.LENGTH_LONG);
        }
    }




}
