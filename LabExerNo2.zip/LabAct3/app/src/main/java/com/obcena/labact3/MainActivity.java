package com.obcena.labact3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etVerify, etUS, etUS1, etUS2, etUS3, etUS4, etUS5, etUS6, etUS7; //declaring variables
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etVerify = findViewById(R.id.etSchool); //assigning value to the variable
        etUS = findViewById(R.id.editUS); //assigning value to the variable
        etUS1 = findViewById(R.id.editUS1); //assigning value to the variable
        etUS2 = findViewById(R.id.editUS2); //assigning value to the variable
        etUS3 = findViewById(R.id.editUS3); //assigning value to the variable
        etUS4 = findViewById(R.id.editUS4); //assigning value to the variable
        etUS5 = findViewById(R.id.editUS5); //assigning value to the variable
        etUS6 = findViewById(R.id.editUS6); //assigning value to the variable
        etUS7 = findViewById(R.id.editUS7); //assigning value to the variable

    }

    public void saveData(View view){
        sp = getSharedPreferences("data1", MODE_PRIVATE); // mode private is a non static constant
        SharedPreferences.Editor editor = sp.edit();
        String us = etUS.getText().toString(); //converting Username to string
        String us1  = etUS1.getText().toString(); //converting Password to string
        String us2  = etUS2.getText().toString(); //converting Password to string
        String us3  = etUS3.getText().toString(); //converting Password to string
        String us4  = etUS4.getText().toString(); //converting Password to string
        String us5  = etUS5.getText().toString(); //converting Password to string
        String us6  = etUS6.getText().toString(); //converting Password to string
        String us7  = etUS7.getText().toString(); //converting Password to string
        editor.putString("school", us); //written in the background
        editor.putString("school1", us1); //written in the background
        editor.putString("school2", us2); //written in the background
        editor.putString("school3", us3); //written in the background
        editor.putString("school4", us4); //written in the background
        editor.putString("school5", us5); //written in the background
        editor.putString("school6", us6); //written in the background
        editor.putString("school7", us7); //written in the background
        editor.commit();
        Toast.makeText(this, "Data was saved.", Toast.LENGTH_LONG);
    }

    public void next (View view){
        Intent i = new Intent(this, Verify.class);
        startActivity(i);
    }





}
